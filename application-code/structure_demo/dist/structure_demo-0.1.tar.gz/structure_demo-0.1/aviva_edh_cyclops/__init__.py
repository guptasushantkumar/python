from .text import joke
